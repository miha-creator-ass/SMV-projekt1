<?php
// Preverimo, če je obrazec oddan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_name = $_POST['student_name'];
    $assignment_title = $_POST['assignment_title'];
    $file = $_FILES['assignment_file'];

    // Preverimo, ali je bila datoteka uspešno naložena
    if ($file['error'] == 0) {
        // Ustvarimo ime datoteke v formatu Priimek Ime – Naslov naloge
        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $new_file_name = $student_name . " - " . $assignment_title . "." . $file_extension;

        // Naložimo datoteko v mapo 'uploads'
        $upload_directory = 'uploads/' . $new_file_name;

        if (move_uploaded_file($file['tmp_name'], $upload_directory)) {
            echo "Naloga uspešno oddana!";
        } else {
            echo "Prišlo je do napake pri nalaganju datoteke.";
        }
    } else {
        echo "Datoteka ni bila uspešno naložena.";
    }
}
?>
