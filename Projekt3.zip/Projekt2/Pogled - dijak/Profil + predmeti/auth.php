<?php
session_start();

function isUser LoggedIn() {
    return isset($_SESSION['user_id']); 
}

if (isUser LoggedIn()) {
    $profileLink = '<a href="profile.php">Moj profil</a>';
} else {
    $loginButton = '<a href="login.php" class="submit-btn">Prijava</a>';
}
?>

