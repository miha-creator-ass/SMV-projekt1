<?php
// Ustvarimo povezavo
$conn = new mysqli($servername, $username, $password, $dbname);

// Preverimo povezavo
if ($conn->connect_error) {
    die("Povezava je spodletela: " . $conn->connect_error);
}

// Nastavimo znakovno kodiranje
$conn->set_charset("utf8"); // Nastavite na ustrezno kodiranje, npr. "utf8" ali "utf8mb4"

// Povezava je uspešna
// Lahko dodate dodatne nastavitve ali funkcije tukaj

?>