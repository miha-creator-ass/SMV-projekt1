<?php

include 'auth.php';

include 'db_connection.php'; 


$user_id = $_SESSION['user_id'];
$nickname = '';
$description = '';
$profile_image = '';

// Pridobimo podatke o uporabniku iz baze
if ($stmt = $conn->prepare("SELECT nickname, description, profile_image FROM users WHERE id = ?")) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($nickname, $description, $profile_image);
    $stmt->fetch();
    $stmt->close();
}

// Obdelava obrazca za posodobitev profila
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nickname = $_POST['nickname'];
    $description = $_POST['description'];
    
    // Obdelava nalaganja slike
    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/"; // Mapa za shranjevanje slik
        $target_file = $target_dir . basename($_FILES["profile_image"]["name"]);
        move_uploaded_file($_FILES["profile_image"]["tmp_name"], $target_file);
        $profile_image = $target_file;
    }

    // Posodobitev podatkov v bazi
    if ($stmt = $conn->prepare("UPDATE users SET nickname = ?, description = ?, profile_image = ? WHERE id = ?")) {
        $stmt->bind_param("sssi", $nickname, $description, $profile_image, $user_id);
        $stmt->execute();
        $stmt->close();

        // Preusmeritev po uspešni posodobitvi
        header("Location: profile.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uredi profil</title>
    <link rel="stylesheet" href="styles.css"> <!-- Povezava na CSS datoteko -->
</head>
<body>

<header>
    <h1>Uredi profil</h1>
    <nav>
        <ul>
            <?php
            // Prikaz povezave do profila ali gumba za prijavo
            if (isset($profileLink)) {
                echo '<li>' . $profileLink . '</li>';
            } else {
                echo '<li>' . $loginButton . '</li>';
            }
            ?>
        </ul>
    </nav>
</header>

<main>
    <form action="" method="POST" enctype="multipart/form-data">
        <div>
            <label for="nickname">Vzdevek:</label>
            <input type="text" id="nickname" name="nickname" value="<?php echo htmlspecialchars($nickname); ?>" required>
        </div>
        <div>
            <label for="description">Opis:</label>
            <textarea id="description" name="description" required><?php echo htmlspecialchars($description); ?></textarea>
        </div>
        <div>
            <label for="profile_image">Profilna slika:</label>
            <input type="file" id="profile_image" name="profile_image" accept="image/*">
            <?php if ($profile_image): ?>
                <img src="<?php echo htmlspecialchars($profile_image); ?>" alt="Profilna slika" style="width: 100px; height: auto;">
            <?php endif; ?>
        </div>
        <div>
            <button type="submit">Shrani spremembe</button>
        </div>
    </form>
</main>

<footer>
    <p>&copy; 2023 Moja Stran</p>
</footer>

</body>
</html>