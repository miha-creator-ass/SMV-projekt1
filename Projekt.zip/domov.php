<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Spletna Učilnica</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Spletna Učilnica</h1>
            <?php include 'nav.php'; ?>
        </div>
    </header>
    <section class="hero">
        <div class="container">
            <h2>Dobrodošli v spletni učilnici!</h2>
            <p>Spletna učilnica omogoča dostop do predavanj, nalog in gradiv na enem mestu. Prijavite ali registrirajte se, da začnete.</p>
            <a href="login.html" class="cta-button">Začnite zdaj</a>
        </div>
    </section>

    <section class="features">
        <div class="container">
            <div class="feature-box">
                <h3>Predmeti</h3>
                <p>Prijavite se na različne predmete, ki jih poučujejo izkušeni učitelji.</p>
            </div>
            <div class="feature-box">
                <h3>Gradiva</h3>
                <p>Preberite ali prenesite gradiva za lažje učenje in pripravo na izpite.</p>
            </div>
            <div class="feature-box">
                <h3>Naloge</h3>
                <p>Oddajte svoje naloge in spremljajte napredek na vsakem predmetu.</p>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2024 Spletna Učilnica. Vse pravice pridržane.</p>
        </div>
    </footer>
</body>
</html>
