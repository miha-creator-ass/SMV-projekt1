<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config.php';

if (!isset($_SESSION['id']) || $_SESSION['user_role'] !== 'dijak') {
    echo "Nimate dovoljenja za ogled te strani.";
    exit;
}

$userId = $_SESSION['id'];

// Pridobi vse predmete za izbiro
$sql = "SELECT * FROM predmet";
$result = $conn->query($sql);

if ($result === false) {
    echo "Napaka pri pridobivanju podatkov o predmetih.";
    exit;
}

// Pridobi trenutno vpisane predmete dijaka
$sql_selected = "SELECT id_predmeta FROM ucenci_predmeti WHERE id_ucenca = ?";
$stmt = $conn->prepare($sql_selected);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result_selected = $stmt->get_result();

$selected_subjects = [];
while ($row = $result_selected->fetch_assoc()) {
    $selected_subjects[] = $row['id_predmeta'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Posodobitev predmetov za dijaka
    $selected_subjects_post = isset($_POST['predmeti']) ? $_POST['predmeti'] : [];

    // Izbriši obstoječe predmete
    $sql_delete = "DELETE FROM ucenci_predmeti WHERE id_ucenca = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $userId);
    $stmt_delete->execute();

    // Dodaj nove predmete
    $sql_insert = "INSERT INTO ucenci_predmeti (id_ucenca, id_predmeta) VALUES (?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);

    foreach ($selected_subjects_post as $predmet_id) {
        $stmt_insert->bind_param("ii", $userId, $predmet_id);
        $stmt_insert->execute();
    }

    echo "Predmeti so bili uspešno posodobljeni.";
    header("Location: uredi_predmete.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <title>Uredi Moje Predmete</title>
    <link rel="stylesheet" href="pred.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Spletna Učilnica</h1>
            <?php include 'nav.php'; ?>
        </div>
    </header>

    <main>
        <div class="subject-container">
            <h2>Uredi predmete</h2>
            <form action="uredi_predmete.php" method="post">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div>
                     <input type="checkbox" name="predmeti[]" value="<?php echo $row['id']; ?>"
                        <?php echo in_array($row['id'], $selected_subjects) ? 'checked' : ''; ?>>
                        <label><?php echo htmlspecialchars($row['naziv']); ?></label>
                    </div>
                 <?php endwhile; ?>
                <button type="submit">Posodobi predmete</button>
            </form>
        </div>
    </main>
    <footer>
        <p>&copy; 2024 Spletna Učilnica. Vse pravice pridržane.</p>
    </footer>
</body>
</html>
