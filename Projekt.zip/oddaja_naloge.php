<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config.php';

if ($_SESSION['user_role'] !== 'dijak') {
    header("Location: login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['assignment_file']) && $_FILES['assignment_file']['error'] === UPLOAD_ERR_OK && isset($_POST['predmet_id'])) {
        $fileTmpPath = $_FILES['assignment_file']['tmp_name'];
        $fileName = $_FILES['assignment_file']['name'];
        $uploadDir = 'uploads/assignments/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $filePath = $uploadDir . $fileName;

        if (move_uploaded_file($fileTmpPath, $filePath)) {
            $ucenec_id = $_SESSION['id'];
            $predmet_id = $_POST['predmet_id'];
            $naslov = $fileName;
            $datum_oddaje = date('Y-m-d H:i:s');
            $pot_do_datoteke = $filePath;

            $stmt = $conn->prepare("INSERT INTO naloge (ucenec_id, predmet_id, naslov, pot_do_datoteke, datum_oddaje) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iisss", $ucenec_id, $predmet_id, $naslov, $pot_do_datoteke, $datum_oddaje);
            $stmt->execute();
            $stmt->close();

            $redirect_url = $_POST['redirect_url'];
            header("Location: " . $redirect_url);
            exit();
        } else {
            echo "Napaka pri shranjevanju datoteke.";
        }
    } else {
        echo "Nalaganje datoteke ni uspelo ali predmet ni določen.";
    }
}
?>
