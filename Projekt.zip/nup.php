<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Spletna Učilnica - Napredna uporaba baz</title>
    <link rel="stylesheet" href="predmeti.css">
</head>
<body>
    <?php
    include 'config.php';

    $currentPage = basename($_SERVER['PHP_SELF'], ".php");
    $predmeti = [
        "slo" => 1,
        "mat" => 2,
        "ang" => 3,
        "rob" => 4,
        "smv" => 5,
        "nup" => 6,
        "rpr" => 7,
        "uip" => 8,
        "soc" => 9,
        "spo" => 10
    ];
    $predmet_id = isset($predmeti[$currentPage]) ? $predmeti[$currentPage] : null;
    ?>

    <header>
        <div class="container">
            <h1>Spletna Učilnica</h1>
            <?php include 'nav.php'; ?>
        </div>
    </header>

    <div class="side-menu">
        <ul>
            <br><br><br>
            <li><a href="slo.php">Slovenščina</a></li>
            <li><a href="mat.php">Matematika</a></li>
            <li><a href="ang.php">Angleščina</a></li>
            <li><a href="rob.php">Računalniško oblikovanje</a></li>
            <li><a href="smv.php">Stroka moderne vsebine</a></li>
            <li><a href="nup.php">Napredna uporaba baz</a></li>
            <li><a href="rpr.php">Računalniški praktikum</a></li>
            <li><a href="uip.php">Uporaba IKT pri poslovanju</a></li>
            <li><a href="soc.php">Sociologija</a></li>
            <li><a href="spo.php">Športna vzgoja</a></li>
        </ul>
    </div>

    <main>
        <section id="description">
            <h2>Napredna uporaba baz</h2>
            <p>V tem predmetu se bomo osredotočili na:</p>
            <ul>
                <li>Napredni SQL</li>
                <li>Analiza podatkov in poslovna inteligenca</li>
                <li>Oblačne podatkovne baze</li>
                <br>
            </ul>
        </section>
        
        <section id="materials">
            <h2>Gradiva</h2>
            <ul>
                <?php
                if ($predmet_id !== null) {
                    $sql = "SELECT naslov, datum_nalaganja FROM gradiva WHERE predmet_id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $predmet_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    while ($row = $result->fetch_assoc()) {
                        echo "<li><a href='uploads/materials/" . htmlspecialchars($row['naslov']) . "'>" . htmlspecialchars($row['naslov']) . "</a> - " . htmlspecialchars($row['datum_nalaganja']) . "</li>";
                    }

                    $stmt->close();
                } else {
                    echo "<li>Predmeta ni mogoče določiti.</li>";
                }
                ?>
            </ul>
            </section>
        
        <section id="submit-assignment">
            <h2>Oddaja nalog</h2>
            <form action="oddaja_naloge.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="predmet_id" value="<?php echo $predmet_id; ?>">
                <input type="hidden" name="redirect_url" value="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
                <div><p>Nalogo oddaj v sledečem formatu: Priimek_Ime_NaslovNaloge.pdf</p></div>
                <br>
                <div class="input-box">
                    <input type="file" id="assignment-file" name="assignment_file" accept=".pdf,.doc,.docx" required>
                </div>
                <br>
                <button type="submit" class="submit-btn">Oddaj nalogo</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Spletna Učilnica. Vse pravice pridržane.</p>
    </footer>
</body>
</html>
