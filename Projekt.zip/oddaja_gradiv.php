<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config.php';

if ($_SESSION['user_role'] !== 'ucitelj') {
    header("Location: login.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['material_file']) && $_FILES['material_file']['error'] === UPLOAD_ERR_OK) {
    $fileTmpPath = $_FILES['material_file']['tmp_name'];
    $fileName = $_FILES['material_file']['name'];
    $uploadDir = 'uploads/materials/';

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $filePath = $uploadDir . $fileName;
    if (move_uploaded_file($fileTmpPath, $filePath)) {
        $predmet_id = $_POST['predmet_id'];
        $naslov = $fileName;
        $datum_nalaganja = date('Y-m-d H:i:s');
        $ucitelj_id = $_SESSION['id']; 

        $stmt = $conn->prepare("INSERT INTO gradiva (predmet_id, ucitelj_id, naslov, datum_nalaganja) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $predmet_id, $ucitelj_id, $naslov, $datum_nalaganja);
        $stmt->execute();
        $stmt->close();

        echo "Gradivo je bilo uspešno naloženo!";
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit();
    } else {
        echo "Napaka pri shranjevanju datoteke.";
    }
} else {
    echo "Nalaganje datoteke ni uspelo.";
}
?>
