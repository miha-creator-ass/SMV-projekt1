<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config.php';
?>

<nav>
    <ul>
        <li><a href="domov.php">Domov</a></li>
        <li><a href="predmeti.php">Predmeti</a></li>
        
        <?php if (isset($_SESSION['id'])): ?>
            <?php if ($_SESSION['user_role'] !== 'ucitelj'): ?>
                <li><a href="uredi_predmete.php">Uredi predmete</a></li>
            <?php endif; ?>
            <li><a href="logout.php">Odjava</a></li>
        <?php else: ?>
            <li><a href="login.html">Prijava</a></li>
        <?php endif; ?>
    </ul>
</nav>
