<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['material_id'])) {
    $material_id = $_POST['material_id'];

    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'ucitelj') {
        $stmt = $conn->prepare("SELECT naslov FROM gradiva WHERE id = ?");
        $stmt->bind_param("i", $material_id);
        $stmt->execute();
        $stmt->bind_result($naslov);
        $stmt->fetch();
        $stmt->close();

        if ($naslov) {
            $filePath = 'uploads/materials/' . $naslov;
            if (file_exists($filePath)) {
                unlink($filePath);
            }

            $stmt = $conn->prepare("DELETE FROM gradiva WHERE id = ?");
            $stmt->bind_param("i", $material_id);
            $stmt->execute();
            $stmt->close();
        }
    }
}

header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
