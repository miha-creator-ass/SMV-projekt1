<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Spletna Učilnica</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'config.php'; ?>
    <header>
        <div class="container">
            <h1>Spletna Učilnica</h1>
            <?php include 'nav.php'; ?>
        </div>
    </header>
    <div class="ucitelji">
        <h2><a href = "slo-ucit.php">Slovenščina</a></h2>
        <br>
        <h2><a href = "mat-ucit.php">Matematika</a></h2>
        <br>
        <h2><a href = "ang-ucit.php">Angleščina</a></h2>
        <br>
        <h2><a href = "rob-ucit.php">Računalniško oblikovanje</a></h2>
        <br>
        <h2><a href = "smv-ucit.php">Stroka Moderne Vsebine</a></h2>
        <br>
        <h2><a href = "nup-ucit.php">Napredna uporaba baz</a></h2>
        <br>
        <h2><a href = "rpr-ucit.php">Računalniški praktikum</a></h2>
        <br>
        <h2><a href = "uip-ucit.php">Uporaba IKT pri poslovanju</a></h2>
        <br>
        <h2><a href = "soc-ucit.php">Sociologija</a></h2>
        <br>
        <h2><a href = "spo-ucit.php">Športna vzgoja</a></h2>
        <br>
    </div>
    <footer>
        <div class="container">
            <p>&copy; 2024 Spletna Učilnica. Vse pravice pridržane.</p>
        </div>
    </footer>
</body>
</html>