<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ime = $_POST['ime'];
    $priimek = $_POST['priimek'];
    $email = $_POST['email'];
    $geslo = $_POST['geslo'];

    $stmt = $conn->prepare("SELECT id FROM Ucenec WHERE email = ? UNION SELECT id FROM Ucitelj WHERE email = ?");
    $stmt->bind_param("ss", $email, $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $_SESSION['error'] = "E-naslov je že registriran!";
        header("Location: register.html");
        exit;
    }

    $stmt->close();

    if (strpos($email, '@admin') !== false) {
        $_SESSION['error'] = "Napaka: Administrator se ne more registrirati. Poskusite prijavo.";
        header("Location: register.html");
        exit;
    }

    if (strpos($email, '@dijak') !== false) {
        $stmt = $conn->prepare("INSERT INTO Ucenec (ime, priimek, email, geslo) VALUES (?, ?, ?, ?)");
    } elseif (strpos($email, '@ucitelj') !== false) {
        $stmt = $conn->prepare("INSERT INTO Ucitelj (ime, priimek, email, geslo) VALUES (?, ?, ?, ?)");
    } else {
        $_SESSION['error'] = "Napaka: E-naslov ni ustrezne vrste.";
        header("Location: register.html");
        exit;
    }

    $stmt->bind_param("ssss", $ime, $priimek, $email, $geslo);
    if ($stmt->execute()) {
        header("Location: domov.php");
        exit;
    } else {
        $_SESSION['error'] = "Registracija ni bila uspešna. Poskusite znova.";
        header("Location: register.html");
        exit;
    }

    $stmt->close();
    $conn->close();
}
?>
