<?php
session_start();
include 'config.php';

if ($_SESSION['user_role'] !== 'dijak') {
    header("Location: domov.php");
    exit;
}

$ucenec_id = $_SESSION['id'];
$izbrani_predmeti = $_POST['predmeti'] ?? [];

$stmt = $conn->prepare("DELETE FROM ucenci_predmeti WHERE id_ucenca = ?");
$stmt->bind_param("i", $ucenec_id);
$stmt->execute();

if (!empty($izbrani_predmeti)) {
    $stmt = $conn->prepare("INSERT INTO ucenci_predmeti (id_ucenca, id_predmeta) VALUES (?, ?)");
    foreach ($izbrani_predmeti as $predmet_id) {
        $stmt->bind_param("ii", $ucenec_id, $predmet_id);
        $stmt->execute();
    }
    $stmt->close();
}

header("Location: predmeti.php");
exit;
