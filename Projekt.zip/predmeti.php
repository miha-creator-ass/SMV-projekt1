<?php
session_start();
include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.html");
    exit();
}

// Check user role
$user_role = $_SESSION['user_role'] ?? 'dijak';
$is_teacher = $user_role === 'ucitelj';

// Prepare SQL query to get subjects based on user role
$user_id = $_SESSION['id'];
if ($is_teacher) {
    // For teachers, fetch subjects they are assigned to
    $sql = "SELECT predmet.naziv FROM predmet 
            JOIN ucitelji_predmeti ON predmet.id = ucitelji_predmeti.id_predmeta 
            WHERE ucitelji_predmeti.id_ucitelja = ?";
} else {
    // For students, fetch subjects they are enrolled in
    $sql = "SELECT predmet.naziv FROM predmet 
            JOIN ucenci_predmeti ON predmet.id = ucenci_predmeti.id_predmeta 
            WHERE ucenci_predmeti.id_ucenca = ?";
}

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Define hardcoded links based on user role
$subject_links = [
    'Slovenščina' => $is_teacher ? 'slo-ucit.php' : 'slo.php',
    'Matematika' => $is_teacher ? 'mat-ucit.php' : 'mat.php',
    'Angleščina' => $is_teacher ? 'ang-ucit.php' : 'ang.php',
    'Računalniško oblikovanje' => $is_teacher ? 'rob-ucit.php' : 'rob.php',
    'Stroka moderne vsebine' => $is_teacher ? 'smv-ucit.php' : 'smv.php',
    'Napredna uporaba baz' => $is_teacher ? 'nup-ucit.php' : 'nup.php',
    'Računalniški praktikum' => $is_teacher ? 'rpr-ucit.php' : 'rpr.php',
    'Uporaba IKT pri poslovanju' => $is_teacher ? 'uip-ucit.php' : 'uip.php',
    'Sociologija' => $is_teacher ? 'soc-ucit.php' : 'soc.php',
    'Športna vzgoja' => $is_teacher ? 'spo-ucit.php' : 'spo.php'
];

// Filter subjects based on user's assigned subjects
$assigned_subjects = [];
while ($row = $result->fetch_assoc()) {
    $subject_name = $row['naziv'];
    if (isset($subject_links[$subject_name])) {
        $assigned_subjects[] = [
            'name' => $subject_name,
            'link' => $subject_links[$subject_name],
        ];
    }
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Spletna Učilnica - Predmeti</title>
    <link rel="stylesheet" href="pred.css"> <!-- Shared CSS file -->
</head>
<body>
    <header>
        <div class="container">
            <h1>Spletna Učilnica</h1>
            <?php include 'nav.php'; ?>
        </div>
    </header>

    <main>
        <div class="subjects-container">
            <h2>Vaši Predmeti</h2>
            <?php if (!empty($assigned_subjects)): ?>
                <ul class="subjects-list">
                    <?php foreach ($assigned_subjects as $subject): ?>
                        <li><a href="<?php echo $subject['link']; ?>"><?php echo htmlspecialchars($subject['name']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p class="no-subjects">Trenutno nimate dodeljenih predmetov.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 Spletna Učilnica. Vse pravice pridržane.</p>
    </footer>
</body>
</html>
