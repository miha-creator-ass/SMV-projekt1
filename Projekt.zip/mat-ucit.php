<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Spletna Učilnica - Matematika</title>
    <link rel="stylesheet" href="predmeti.css">
</head>
<body>
    <?php
    include 'config.php';

    $currentPage = basename($_SERVER['PHP_SELF'], ".php");
    $predmeti = [
        "slo-ucit" => 1,
        "mat-ucit" => 2,
        "ang-ucit" => 3,
        "rob-ucit" => 4,
        "smv-ucit" => 5,
        "nup-ucit" => 6,
        "rpr-ucit" => 7,
        "uip-ucit" => 8,
        "soc-ucit" => 9,
        "spo-ucit" => 10
    ];
    $predmet_id = isset($predmeti[$currentPage]) ? $predmeti[$currentPage] : null;
    ?>

    <header>
        <div class="container">
            <h1>Spletna Učilnica</h1>
            <?php include 'nav.php'; ?>
        </div>
    </header>
    
    <div class="side-menu">
        <ul>
            <li><a href="slo-ucit.php">Slovenščina</a></li>
            <li><a href="mat-ucit.php">Matematika</a></li>
            <li><a href="ang-ucit.php">Angleščina</a></li>
            <li><a href="rob-ucit.php">Računalniško oblikovanje</a></li>
            <li><a href="smv-ucit.php">Stroka moderne vsebine</a></li>
            <li><a href="nup-ucit.php">Napredna uporaba baz</a></li>
            <li><a href="rpr-ucit.php">Računalniški praktikum</a></li>
            <li><a href="uip-ucit.php">Uporaba IKT pri poslovanju</a></li>
            <li><a href="soc-ucit.php">Sociologija</a></li>
            <li><a href="spo-ucit.php">Športna vzgoja</a></li>
        </ul>
    </div>
    
    <main>
        <section id="description">
            <h2>Matematika</h2>
            <p>V tem predmetu se bomo osredotočili na:</p>
            <ul>
                <li>Osnovne matematične operacije</li>
                <li>Algebrske izraze in enačbe</li>
                <li>Geometrijske oblike in izračuni</li>
                <li>Funkcije in grafe</li>
            </ul>
        </section>

        <section id="submitted-assignments">
            <h2>Oddane naloge učencev</h2>
            <ul>
                <?php
                if ($predmet_id !== null) {
                    $sql = "SELECT ucenec.ime, ucenec.priimek, naloge.naslov, naloge.datum_oddaje FROM naloge 
                            JOIN ucenec ON naloge.ucenec_id = ucenec.id 
                            WHERE naloge.predmet_id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $predmet_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<li>" . htmlspecialchars($row['ime']) . " " . htmlspecialchars($row['priimek']) .
                                " - <a href='uploads/assignments/" . htmlspecialchars($row['naslov']) . "' download>" .
                                htmlspecialchars($row['naslov']) . "</a> - " . htmlspecialchars($row['datum_oddaje']) . "</li>";
                        }
                    } else {
                        echo "<li>Ni oddanih nalog za ta predmet.</li>";
                    }
                    $stmt->close();
                }
                ?>
            </ul>
        </section>

        <section id="submit-materials">
            <h2>Oddaja gradiva</h2>
            <form action="oddaja_gradiv.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="predmet_id" value="<?php echo $predmet_id; ?>">
                <div class="input-box">
                    <input type="file" id="material-file" name="material_file" accept=".pdf,.doc,.docx" required>
                </div>
                <button type="submit" class="submit-btn">Oddaj gradivo</button>
            </form>
        </section>

        <section id="materials">
            <h2>Gradiva za predmet</h2>
            <ul>
                <?php
                if ($predmet_id !== null) {
                    $sql = "SELECT id, naslov, datum_nalaganja FROM gradiva WHERE predmet_id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $predmet_id);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<li><a href='uploads/materials/" . htmlspecialchars($row['naslov']) . "' download>" . 
                                 htmlspecialchars($row['naslov']) . "</a> - " . htmlspecialchars($row['datum_nalaganja']) . 
                                 "<form action='izbris_gradiva.php' method='POST' style='display:inline;'>
                                    <input type='hidden' name='material_id' value='" . htmlspecialchars($row['id']) . "'>
                                    <button type='submit' class='delete-btn'>Izbriši</button>
                                 </form></li>";
                        }
                    } else {
                        echo "<li>Ni naloženih gradiv za ta predmet.</li>";
                    }
                    $stmt->close();
                }
                ?>
            </ul>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2024 Spletna Učilnica. Vse pravice pridržane.</p
