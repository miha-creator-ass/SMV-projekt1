<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config.php'; // povezava z bazo

// Preveri, če je uporabnik administrator
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: login.php'); // če ni admin, ga preusmeri na prijavo
    exit();
}

// Funkcija za prikaz sporočil
$message = '';

// Vpis, urejanje ali brisanje predmetov, učiteljev, učencev in povezav med njimi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vpis, urejanje ali brisanje predmetov
    if (isset($_POST['action']) && $_POST['entity'] === 'predmet') {
        $naziv = $_POST['naziv'];
        $id = $_POST['id'] ?? null;

        if ($_POST['action'] === 'vpis') {
            $stmt = $conn->prepare("INSERT INTO predmet (naziv) VALUES (?)");
            $stmt->bind_param("s", $naziv);
            $stmt->execute();
            $message = "Predmet uspešno dodan.";
        } elseif ($_POST['action'] === 'popravljanje' && $id) {
            $stmt = $conn->prepare("UPDATE predmet SET naziv = ? WHERE id = ?");
            $stmt->bind_param("si", $naziv, $id);
            $stmt->execute();
            $message = "Predmet uspešno posodobljen.";
        } elseif ($_POST['action'] === 'brisanje' && $id) {
            $stmt = $conn->prepare("DELETE FROM predmet WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $message = "Predmet uspešno izbrisan.";
        }
    }
    // Vpis, urejanje ali brisanje učiteljev
    elseif (isset($_POST['action']) && $_POST['entity'] === 'ucitelj') {
        $ime = $_POST['ime'];
        $priimek = $_POST['priimek'];
        $id = $_POST['id'] ?? null;

        if ($_POST['action'] === 'vpis') {
            $stmt = $conn->prepare("INSERT INTO ucitelj (ime, priimek) VALUES (?, ?)");
            $stmt->bind_param("ss", $ime, $priimek);
            $stmt->execute();
            $message = "Učitelj uspešno dodan.";
        } elseif ($_POST['action'] === 'popravljanje' && $id) {
            $stmt = $conn->prepare("UPDATE ucitelj SET ime = ?, priimek = ? WHERE id = ?");
            $stmt->bind_param("ssi", $ime, $priimek, $id);
            $stmt->execute();
            $message = "Učitelj uspešno posodobljen.";
        } elseif ($_POST['action'] === 'brisanje' && $id) {
            $stmt = $conn->prepare("DELETE FROM ucitelj WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $message = "Učitelj uspešno izbrisan.";
        }
    }
    // Vpis, urejanje ali brisanje učencev
    elseif (isset($_POST['action']) && $_POST['entity'] === 'ucenec') {
        $ime = $_POST['ime'];
        $priimek = $_POST['priimek'];
        $email = $_POST['email'];
        $id = $_POST['id'] ?? null;

        if ($_POST['action'] === 'vpis') {
            $stmt = $conn->prepare("INSERT INTO ucenec (ime, priimek, email) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $ime, $priimek, $email);
            $stmt->execute();
            $message = "Učenec uspešno dodan.";
        } elseif ($_POST['action'] === 'popravljanje' && $id) {
            $stmt = $conn->prepare("UPDATE ucenec SET ime = ?, priimek = ?, email = ? WHERE id = ?");
            $stmt->bind_param("sssi", $ime, $priimek, $email, $id);
            $stmt->execute();
            $message = "Učenec uspešno posodobljen.";
        } elseif ($_POST['action'] === 'brisanje' && $id) {
            $stmt = $conn->prepare("DELETE FROM ucenec WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $message = "Učenec uspešno izbrisan.";
        }
    }
    // Vpis ali brisanje povezav med učitelji in predmeti
    elseif (isset($_POST['action']) && $_POST['entity'] === 'ucitelji_predmeti') {
        $id_ucitelja = $_POST['id_ucitelja'];
        $id_predmeta = $_POST['id_predmeta'];

        if ($_POST['action'] === 'dodaj') {
            $stmt = $conn->prepare("INSERT INTO ucitelji_predmeti (id_ucitelja, id_predmeta) VALUES (?, ?)");
            $stmt->bind_param("ii", $id_ucitelja, $id_predmeta);
            $stmt->execute();
            $message = "Povezava med učiteljem in predmetom uspešno dodana.";
        } elseif ($_POST['action'] === 'odstrani') {
            $stmt = $conn->prepare("DELETE FROM ucitelji_predmeti WHERE id_ucitelja = ? AND id_predmeta = ?");
            $stmt->bind_param("ii", $id_ucitelja, $id_predmeta);
            $stmt->execute();
            $message = "Povezava med učiteljem in predmetom uspešno odstranjena.";
        }
    }
    // Vpis ali brisanje povezav med učenci in predmeti
    elseif (isset($_POST['action']) && $_POST['entity'] === 'ucenci_predmeti') {
        $id_ucenca = $_POST['id_ucenca'];
        $id_predmeta = $_POST['id_predmeta'];

        if ($_POST['action'] === 'dodaj') {
            $stmt = $conn->prepare("INSERT INTO ucenci_predmeti (id_ucenca, id_predmeta) VALUES (?, ?)");
            $stmt->bind_param("ii", $id_ucenca, $id_predmeta);
            $stmt->execute();
            $message = "Povezava med učencem in predmetom uspešno dodana.";
        } elseif ($_POST['action'] === 'odstrani') {
            $stmt = $conn->prepare("DELETE FROM ucenci_predmeti WHERE id_ucenca = ? AND id_predmeta = ?");
            $stmt->bind_param("ii", $id_ucenca, $id_predmeta);
            $stmt->execute();
            $message = "Povezava med učencem in predmetom uspešno odstranjena.";
        }
    }
}

// Pridobi trenutne podatke za prikaz
$predmeti = $conn->query("SELECT * FROM predmet");
$ucitelji = $conn->query("SELECT * FROM ucitelj");
$ucenci = $conn->query("SELECT * FROM ucenec");
$povezave_ucitelji = $conn->query("SELECT ucitelj.ime, ucitelj.priimek, predmet.naziv FROM ucitelji_predmeti 
                                   JOIN ucitelj ON ucitelji_predmeti.id_ucitelja = ucitelj.id 
                                   JOIN predmet ON ucitelji_predmeti.id_predmeta = predmet.id");
$povezave_ucenci = $conn->query("SELECT ucenec.ime, ucenec.priimek, predmet.naziv FROM ucenci_predmeti 
                                 JOIN ucenec ON ucenci_predmeti.id_ucenca = ucenec.id 
                                 JOIN predmet ON ucenci_predmeti.id_predmeta = predmet.id");
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <title>Administracija sistema</title>
    <link rel="stylesheet" href="admin.css"> <!-- obstoječi CSS -->
</head>
<body>

    <div class="container">
        <h1>Administracija sistema</h1>
        <?php if ($message) echo "<div class='message'>$message</div>"; ?>

        <!-- Upravljanje predmetov -->
        <h2>Upravljanje predmetov</h2>
        <form method="POST" action="">
            <input type="hidden" name="entity" value="predmet">
            <label for="naziv">Naziv predmeta:</label>
            <input type="text" id="naziv" name="naziv" required>

            <label for="id">ID (za urejanje ali brisanje):</label>
            <input type="number" id="id" name="id">

            <button type="submit" name="action" value="vpis">Vpis predmeta</button>
            <button type="submit" name="action" value="popravljanje">Popravljanje predmeta</button>
            <button type="submit" name="action" value="brisanje">Brisanje predmeta</button>
        </form>

        <!-- Seznam predmetov -->
        <h3>Seznam predmetov</h3>
        <ul>
            <?php
            $predmeti = $conn->query("SELECT * FROM predmet"); // Ponovno pridobimo podatke
            while ($predmet = $predmeti->fetch_assoc()): ?>
                <li>ID: <?php echo $predmet['id']; ?>, Naziv: <?php echo htmlspecialchars($predmet['naziv']); ?></li>
            <?php endwhile; ?>
        </ul>

        <!-- Upravljanje učiteljev -->
        <h2>Upravljanje učiteljev</h2>
        <form method="POST" action="">
            <input type="hidden" name="entity" value="ucitelj">
            <label for="ime">Ime učitelja:</label>
            <input type="text" id="ime" name="ime" required>

            <label for="priimek">Priimek učitelja:</label>
            <input type="text" id="priimek" name="priimek" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="id">ID (za urejanje ali brisanje):</label>
            <input type="number" id="id" name="id">

            <button type="submit" name="action" value="vpis">Vpis učitelja</button>
            <button type="submit" name="action" value="popravljanje">Popravljanje učitelja</button>
            <button type="submit" name="action" value="brisanje">Brisanje učitelja</button>
        </form>

        <!-- Seznam učiteljev -->
        <h3>Seznam učiteljev</h3>
        <ul>
            <?php 
            $ucitelji = $conn->query("SELECT * FROM ucitelj");
            while ($ucitelj = $ucitelji->fetch_assoc()): ?>
                <li>ID: <?php echo $ucitelj['id']; ?>, Ime: <?php echo htmlspecialchars($ucitelj['ime']); ?>, Priimek: <?php echo htmlspecialchars($ucitelj['priimek']) ?>, Email: <?php echo htmlspecialchars($ucitelj['email']); ?></li>
            <?php endwhile; ?>
        </ul>

        <!-- Upravljanje učencev -->
        <h2>Upravljanje učencev</h2>
        <form method="POST" action="">
            <input type="hidden" name="entity" value="ucenec">
            <label for="ime">Ime učenca:</label>
            <input type="text" id="ime" name="ime" required>

            <label for="priimek">Priimek učenca:</label>
            <input type="text" id="priimek" name="priimek" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="id">ID (za urejanje ali brisanje):</label>
            <input type="number" id="id" name="id">

            <button type="submit" name="action" value="vpis">Vpis učenca</button>
            <button type="submit" name="action" value="popravljanje">Popravljanje učenca</button>
            <button type="submit" name="action" value="brisanje">Brisanje učenca</button>
        </form>

        <!-- Seznam učencev -->
        <h3>Seznam učencev</h3>
        <ul>
            <?php
            $ucenci = $conn->query("SELECT * FROM ucenec"); // Ponovno pridobimo podatke
            while ($ucenec = $ucenci->fetch_assoc()): ?>
                <li>ID: <?php echo $ucenec['id']; ?>, Ime: <?php echo htmlspecialchars($ucenec['ime']); ?>, Priimek: <?php echo htmlspecialchars($ucenec['priimek']); ?>, Email: <?php echo htmlspecialchars($ucenec['email']); ?></li>
            <?php endwhile; ?>
        </ul>

        <!-- Upravljanje povezav med učitelji in predmeti -->
        <h2>Določanje predmetov, ki jih poučujejo učitelji</h2>
        <form method="POST" action="">
            <input type="hidden" name="entity" value="ucitelji_predmeti">
            <label for="id_ucitelja">Izberite učitelja:</label>
            <select id="id_ucitelja" name="id_ucitelja" required>
                <?php
                $ucitelji = $conn->query("SELECT * FROM ucitelj"); // Ponovno pridobimo podatke
                while ($ucitelj = $ucitelji->fetch_assoc()): ?>
                    <option value="<?php echo $ucitelj['id']; ?>"><?php echo htmlspecialchars($ucitelj['ime'] . " " . $ucitelj['priimek']); ?></option>
                <?php endwhile; ?>
            </select>

            <label for="id_predmeta">Izberite predmet:</label>
            <select id="id_predmeta" name="id_predmeta" required>
                <?php
                $predmeti = $conn->query("SELECT * FROM predmet"); // Ponovno pridobimo podatke
                while ($predmet = $predmeti->fetch_assoc()): ?>
                    <option value="<?php echo $predmet['id']; ?>"><?php echo htmlspecialchars($predmet['naziv']); ?></option>
                <?php endwhile; ?>
            </select>

            <button type="submit" name="action" value="dodaj">Dodaj povezavo</button>
            <button type="submit" name="action" value="odstrani">Odstrani povezavo</button>
        </form>

        <!-- Seznam povezav med učitelji in predmeti -->
        <h3>Povezave med učitelji in predmeti</h3>
        <ul>
            <?php while ($povezava = $povezave_ucitelji->fetch_assoc()): ?>
                <li><?php echo htmlspecialchars($povezava['ime'] . " " . $povezava['priimek']); ?> poučuje <?php echo htmlspecialchars($povezava['naziv']); ?></li>
            <?php endwhile; ?>
        </ul>

        <!-- Upravljanje povezav med učenci in predmeti -->
        <h2>Določanje predmetov, ki jih obiskujejo učenci</h2>
        <form method="POST" action="">
            <input type="hidden" name="entity" value="ucenci_predmeti">
            <label for="id_ucenca">Izberite učenca:</label>
            <select id="id_ucenca" name="id_ucenca" required>
                <?php
                $ucenci = $conn->query("SELECT * FROM ucenec"); // Ponovno pridobimo podatke
                while ($ucenec = $ucenci->fetch_assoc()): ?>
                    <option value="<?php echo $ucenec['id']; ?>"><?php echo htmlspecialchars($ucenec['ime'] . " " . $ucenec['priimek']); ?></option>
                <?php endwhile; ?>
            </select>

            <label for="id_predmeta">Izberite predmet:</label>
            <select id="id_predmeta" name="id_predmeta" required>
                <?php
                $predmeti = $conn->query("SELECT * FROM predmet"); // Ponovno pridobimo podatke
                while ($predmet = $predmeti->fetch_assoc()): ?>
                    <option value="<?php echo $predmet['id']; ?>"><?php echo htmlspecialchars($predmet['naziv']); ?></option>
                <?php endwhile; ?>
            </select>

            <button type="submit" name="action" value="dodaj">Dodaj povezavo</button>
            <button type="submit" name="action" value="odstrani">Odstrani povezavo</button>
        </form>

        <!-- Seznam povezav med učenci in predmeti -->
        <h3>Povezave med učenci in predmeti</h3>
        <ul>
            <?php while ($povezava = $povezave_ucenci->fetch_assoc()): ?>
                <li><?php echo htmlspecialchars($povezava['ime'] . " " . $povezava['priimek']); ?> obiskuje <?php echo htmlspecialchars($povezava['naziv']); ?></li>
            <?php endwhile; ?>
        </ul>
    </div>
    <a href="logout.php" class="logout-button">Odjava</a>
</body>
</html>
