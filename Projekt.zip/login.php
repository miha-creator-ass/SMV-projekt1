<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $geslo = $_POST['geslo'];

    if (strpos($email, '@admin') !== false) {
        $stmt = $conn->prepare("SELECT id, geslo FROM Administrator WHERE email = ?");
        $user_role = 'admin';
    } elseif (strpos($email, '@dijak') !== false) {
        $stmt = $conn->prepare("SELECT id, geslo FROM Ucenec WHERE email = ?");
        $user_role = 'dijak';
    } elseif (strpos($email, '@ucitelj') !== false) {
        $stmt = $conn->prepare("SELECT id, geslo FROM Ucitelj WHERE email = ?");
        $user_role = 'ucitelj';
    } else {
        $_SESSION['error'] = "Napaka: E-naslov ni ustrezne vrste.";
        header("Location: login.html");
        exit;
    }

    if (!$stmt) {
        $_SESSION['error'] = "Napaka pri dostopu do baze.";
        header("Location: login.html");
        exit;
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $shrani_geslo);
        $stmt->fetch();

        if ($geslo === $shrani_geslo) {
            $_SESSION['id'] = $id;
            $_SESSION['user_role'] = $user_role;

            if ($user_role === 'admin') {
                header("Location: admin.php");
            } else {
                header("Location: domov.php");
            }
            exit;
        } else {
            $_SESSION['error'] = "Napačno geslo.";
            header("Location: login.html");
            exit;
        }
    } else {
        $_SESSION['error'] = "Uporabnik s tem e-naslovom ne obstaja.";
        header("Location: login.html");
        exit;
    }

    $stmt->close();
    $conn->close();
}
?>
